OCL grammar
===========

The Object Constraint Language (OCL) is a declarative language for describing
rules that apply to Unified Modeling Language (UML) models developed at IBM and
now part of the UML standard. (More on Wikipedia_)

``OCL.cf``
  Grammar for the language. Updated to OCL 2.
``example.ocl``
  Example

.. _Wikipedia: https://en.wikipedia.org/wiki/Object_Constraint_Language
