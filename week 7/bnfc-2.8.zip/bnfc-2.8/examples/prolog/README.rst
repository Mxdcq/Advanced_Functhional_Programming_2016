Prolog grammar
==============

Prolog is a general purpose logic programming language associated with
artificial intelligence and computational linguistics. (More on Wikipedia_)

``Prolog.cf``
  lbnf grammar for prolog
``small.pl``
  short example
``simpsons.pl``
  longer example


.. _Wikipedia: https://en.wikipedia.org/wiki/Prolog
