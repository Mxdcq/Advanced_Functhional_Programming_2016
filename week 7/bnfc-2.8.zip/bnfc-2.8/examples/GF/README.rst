GF grammar
==========

GF, Grammatical Framework, is a programming language for multilingual grammar
applications. (More on `GF official site`_)

``gf.cf``
  Grammar for (an old version of) the GF language.
``example.gf``
  A Small Romance Resource Syntax.

.. _GF official site: http://www.grammaticalframework.org/
