.. BNFC documentation master file, created by
   sphinx-quickstart on Tue Jan  7 18:37:21 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to BNFC's documentation!
================================

`Google Group <https://groups.google.com/forum/#!forum/bnfc-dev>`_
| `Github <https://github.com/bnfc/bnfc>`_
| `Hackage <http://hackage.haskell.org/package/BNFC>`_

.. toctree::
   :maxdepth: 2

   user_guide
   lbnf
   changes
   othertools
   dev/release


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

