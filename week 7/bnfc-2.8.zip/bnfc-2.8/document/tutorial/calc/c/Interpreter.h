#include "Absyn.h"

int interpret(Exp p);
